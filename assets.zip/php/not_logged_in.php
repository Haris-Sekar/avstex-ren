<?php 
include("./conn.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AVS TEXTILES</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <div class="nav_container">
        <div class="nav">
            <ul>
                <a href="../index.php"><li class="nav-title" style="float: left;">AVS TEXTILES</li></a>
                <a href="./login.php"><li id="nav_items">Login</li></a>
                <a href=""><li id="nav_items">About us</li></a>
                <a href=""><li id="nav_items">Collections</li></a>
                <a href="../index.php"><li id="nav_items">Home</li></a>
            </ul>
        </div>
    </div>
</body>
</html>