<?php 
include("./admin_header.php");
?>
<div class="dashboard">
    <div class="order_count">
        <p id="ord"> No of Orders <br><br> null</p>
    </div>
    <div class="order_count">
        <p id="ord"> Total Sales<br>(month)<br> null</p>
    </div>
    <div class="order_count">
        <p id="ord"> Total Sales <br><br> null</p>
    </div>
    
</div>
